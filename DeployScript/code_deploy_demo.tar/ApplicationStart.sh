#!/bin/bash
docker run -p 5000:5000 --name flask-devops -d 129729052534.dkr.ecr.ap-northeast-1.amazonaws.com/iii-devops-ecr:latest
